import pygame
import math
pygame.init()

width = 500
height = 700

Screen_width = width
Screen_height = height
screen = pygame.display.set_mode((Screen_width, Screen_height))

class backGround():
    def __init__(self, win, image, direction):
        #true -> direction : down 
        #false -> direction : up
        self.win = win
        self.direction = direction      
        self.image = image
        self.image = pygame.transform.scale(self.image, (width, height))
        self.rect = self.image.get_rect()
        
        self.reset()
        
        self.move = True
        
    def update(self, speed):
        if self.move:
            if self.direction:
                self.y1 -= speed
                self.y2 -= speed
                
                if self.y1 <= -height:
                    self.y1 = height
                if self.y2 <= -height:
                    self.y2 = height
            elif not self.direction:
                self.y1 += speed
                self.y2 += speed
                
                if self.y1 >= height:
                    self.y1 = -height
                if self.y2 >= height:
                    self.y2 = -height
                
        self.win.blit(self.image, (self.x, self.y1))
        self.win.blit(self.image, (self.x, self.y2))
        
    def reset(self):
        if self.direction:
            
            self.x = 0
            self.y1 = 0
            self.y2 = height
        elif not self.direction:
            
            self.x = 0
            self.y1 = 0
            self.y2 = -height
            
            

        