import pygame

pygame.init()

class Player:
    def __init__(self, x, y, image):
        self.x = x
        self.y = y
        self.image = image
        
        self.color = (250, 120, 60)
        
        # change the size (e.g., 32x32 pixels)
        self.image = pygame.transform.scale(self.image, (32, 40))
        self.rect = self.image.get_rect()
        self.rect.topleft = (self.x,self.y)
        
        self.velX = 0
        self.velY = 0
        
        self.leftPressed = False
        self.rightPressed = False
        self.upPressed = False 
        self.downPressed = False 
        
        self.speed = 4
        
    def draw(self, screen):
        screen.blit(self.image, self.rect.topleft)
        
    def update(self):
        self.velX = 0
        self.velY = 0
        if self.leftPressed and not self.rightPressed:
            if not self.x <= 0:
                self.velX = -self.speed 
        if self.rightPressed and not self.leftPressed:
            if not self.x >= 500 - 32:
                self.velX = self.speed
        if self.upPressed and not self.downPressed:
            if not self.y <= 0:
                self.velY = -self.speed
        if self.downPressed and not self.upPressed:
            if not self.y >= 700 - 40:
                self.velY = self.speed
        
        self.x += self.velX
        self.y += self.velY
        
        self.rect.topleft = (int(self.x), int(self.y))
        
    def getRect(self):
        return self.rect
        