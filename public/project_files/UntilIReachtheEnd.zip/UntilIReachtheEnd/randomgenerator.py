import pygame
import math
import random

pygame.init()

width = 500
height = 700

class randomGenerator():
    def __init__(self, win, image, direction, sizeWidth, sizeHeight, start):
        #true -> direction : up 
        #false -> direction : down
        self.win = win
        self.direction = direction      
        self.image = image
        self.width = sizeWidth
        self.height = sizeHeight
        self.image = pygame.transform.scale(self.image, (self.width, self.height))
        self.rect = self.image.get_rect()
        self.y = start
        self.x = random.randint(0, 500 - self.width)
        
        self.move = True
        
        self.rect.topleft = (self.x,self.y)

    def update(self, speed):
        if self.move:
            if self.direction:
                self.y -= speed
                
                if self.y <= 0 - self.height:
                    self.y = height
                    self.x = random.randint(0, 500 - self.width)

            elif not self.direction:
                self.y += speed

                if self.y >= height:
                    self.y = 0 - self.height
                    self.x = random.randint(0, 500 - self.width)

        self.rect.topleft = (int(self.x), int(self.y))
        
        self.win.blit(self.image, self.rect.topleft)
        
        
    def getRect(self):
        return self.rect
        
            
            

        