import pygame, sys
import button
import PlayerClass
import os
import time
import math 
from objects import backGround 
from randomgenerator import randomGenerator
# import sprite
# from spritesheet import spriteSheet

pygame.init()
pygame.mixer.init()

width = 500
height = 700
Screen_width = width
Screen_height = height
VOL = 1
DIFFICULTY = 1

level = "Mantle"
level_text = ""

score = 0

screen = pygame.display.set_mode((Screen_width, Screen_height))
surface = pygame.Surface((width, height), pygame.SRCALPHA)
clock = pygame.time.Clock()
font = pygame.font.SysFont("arialblack", 20)
textColor = (255,255,255)
black = (0,0,0)
 
# load button images
start_image = pygame.image.load('Assets/start_button.png').convert_alpha()
exit_image = pygame.image.load('Assets/exit_button.png').convert_alpha()
option_image = pygame.image.load('Assets/option_button.png').convert_alpha()

# load menu buttons
DIFF_PLUS_IMAGE = pygame.image.load('Assets/Plus.png').convert_alpha()
DIFF_MINUS_IMAGE = pygame.image.load('Assets/Minus.png').convert_alpha()
VOL_PLUS_IMAGE = pygame.image.load('Assets/Plus_vol.png').convert_alpha()
VOL_MINUS_IMAGE = pygame.image.load('Assets/Minus_vol.png').convert_alpha()
MUSIC_ON_IMAGE = pygame.image.load('Assets/music_on.png').convert_alpha()
MUSIC_OFF_IMAGE = pygame.image.load('Assets/music_off.png').convert_alpha()
option_exit_image = pygame.image.load('Assets/Minus.png').convert_alpha()
charactor_image = pygame.image.load('Assets/mole1.png').convert_alpha()

# setting buttons 
POS_DIFFICULTY_BTN = button.Button(380, 180, DIFF_PLUS_IMAGE, 0.12)
NEG_DIFFICULTY_BTN = button.Button(50, 180, DIFF_MINUS_IMAGE, 0.12)
POS_VOLUME_BTN = button.Button(380, 330, VOL_PLUS_IMAGE, 0.12)
NEG_VOLUME_BTN = button.Button(50, 330,VOL_MINUS_IMAGE, 0.12)
MUS_OFF_BTN = button.Button(50, 480, MUSIC_OFF_IMAGE, 0.12)
MUS_ON_BTN = button.Button(380, 480, MUSIC_ON_IMAGE, 0.12)
exit_menu_btn = button.Button(380, 30, option_exit_image, 0.12)

def mainMenu():
    
    logo_image = pygame.image.load('Assets/Logo.PNG').convert_alpha()
    logo_image = pygame.transform.scale(logo_image, (300, 150))
    #music play
    pygame.mixer.music.stop()
    pygame.mixer.music.unload()
    pygame.mixer.music.load('Assets/main_music.mp3')
    pygame.mixer.music.play(-1)
    
    time.sleep(3)
    
    pygame.display.set_caption("Menu")
    
    #create button instances
    start_btn = button.Button(110, 200, start_image, 0.5)
    option_btn = button.Button(110, 350, option_image, 0.5)
    exit_btn = button.Button(110, 500, exit_image, 0.5)

    bg1_image = pygame.image.load('Assets/ground1.png').convert_alpha()
    
    bg1_width = bg1_image.get_width()
    bg1_image = pygame.transform.scale(bg1_image, (width, height))
    
    screen.blit(bg1_image, (0,0))
    run = True
    
    while run:
        clock.tick(60)
        
        screen.blit(logo_image, (100, 50))
        
        

        if start_btn.draw(screen):
            run = False
        
        if exit_btn.draw(screen):
            pygame.quit()
            sys.exit()

        if option_btn.draw(screen):
            optionMenu()


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        pygame.display.update()
    storyScene()

def storyScene():    
    clock.tick(15)    
    screen.fill('white')    
      
    pygame.display.set_caption("Story begins")    
    # load story scene image    
    mole_story_image = pygame.image.load('Assets/mole_story_scene.jpg')   
    mole_story = pygame.transform.scale(mole_story_image, (width, height))    
    run = True   
    while run:        
        screen.blit(mole_story, (0, 0))        
        pygame.time.delay(15000)        
        run = False        
        for event in pygame.event.get():            
            if event.type == pygame.QUIT:                
                pygame.quit()                
                sys.exit()        
        pygame.display.update()   
    gameMenu()
    
def endingScene():    
    clock.tick(15)    
    screen.fill('white')    
      
    pygame.display.set_caption("ending..")    
    # load story scene image    
    mole_story_image = pygame.image.load('Assets/ending.jpg')   
    mole_story = pygame.transform.scale(mole_story_image, (width, height))    
    run = True   
    while run:        
        screen.blit(mole_story, (0, 0))        
        pygame.time.delay(30000)        
        run = False        
        for event in pygame.event.get():            
            if event.type == pygame.QUIT:                
                pygame.quit()                
                sys.exit()        
        pygame.display.update()   
    mainMenu()

def drawPause():
    global level_text
    pygame.draw.rect(surface, (128,128,128, 150), [0, 0, width, height])
    pygame.draw.rect(surface, 'dark gray', [50, 600, 400, 50], 0, 10)
    surface.blit (font.render('Game Paused: Escape to Resume', True, 'black'), (65, 610))
    surface.blit (font.render(level_text, True, textColor), (0, 0))
    surface.blit (font.render(level, True, textColor), (width * 2/5, 0))
    screen.blit(surface, (0,0))
    
def drawGameOver():
    global level_text
    pygame.draw.rect(surface, (128,128,128, 150), [0, 0, width, height])
    pygame.draw.rect(surface, 'dark gray', [50, 600, 400, 50], 0, 10)
    surface.blit (font.render('Game Over! Try again!', True, 'black'), (65, 610))
    surface.blit (font.render(level_text, True, textColor), (0, 0))
    surface.blit (font.render(level, True, textColor), (width * 2/5, 0))
    screen.blit(surface, (0,0))

def drawDeath():
    global level_text
    pygame.draw.rect(surface, (128,128,128, 150), [0, 0, width, height])
    pygame.draw.rect(surface, 'dark gray', [50, 600, 400, 50], 0, 10)
    surface.blit (font.render('Game Over! Press ESC to return', True, 'black'), (65, 610))
    surface.blit (font.render(level_text, True, textColor), (0, 0))
    surface.blit (font.render(level, True, textColor), (width * 2/5, 0))
    screen.blit(surface, (0,0))
    
def draw_button_text(text, font, TEXT_COL, screen_width, y):
    # Render the text
    img = font.render(text, True, TEXT_COL)

    # Get the width of the rendered text
    text_width = img.get_width()

    # Calculate the x-coordinate to center the text horizontally
    x = (screen_width - text_width) // 2

    # Clear the area where the text will be displayed
    screen.fill((0, 0, 0), (x, y, text_width, img.get_height()))

    # Blit the text onto the background
    screen.blit(img, (x, y))
    
def draw_text(text, font, tect_col, x, y):
    img = font.render(text, True, textColor)
    screen.blit(img, (x,y))

def draw_button_text(text, font, TEXT_COL, screen_width, y):
    # Render the text
    img = font.render(text, True, TEXT_COL)

    # Get the width of the rendered text
    text_width = img.get_width()

    # Calculate the x-coordinate to center the text horizontally
    x = (screen_width - text_width) // 2

    # Clear the area where the text will be displayed
    screen.fill((0, 0, 0), (x, y, text_width, img.get_height()))

    # Blit the text onto the background
    screen.blit(img, (x, y))

def draw_text_disappear(text, font, TEXT_COL, screen_width, y):
    # Render the text
    img = font.render(text, True, TEXT_COL)

    # Get the width of the rendered text
    text_width = img.get_width()

    # Calculate the x-coordinate to center the text horizontally
    x = (screen_width - text_width) // 2

    # Clear the area where the text will be displayed
    screen.fill((0, 0, 0), (x, y, text_width, img.get_height()))

    # Blit the text
    screen.blit(img, (x, y))
    
    #wait for 0.1 sec
    pygame.time.delay(100)

    # Clear the area where the text was displayed
    screen.fill((0, 0, 0), (x, y, text_width, img.get_height()))

    screen.blit(img, (x, y))

def optionMenu():
    
    global VOL
    global DIFFICULTY

    pygame.display.set_caption("option")
    
    while True:
        bg1_image = pygame.image.load('Assets/ground1.png').convert_alpha()
        bg1_width = bg1_image.get_width()
        bg1_image = pygame.transform.scale(bg1_image, (width, height))
    
        screen.blit(bg1_image, (0,0))
        
        pygame.draw.rect(surface, 'dark gray', [50, 600, 400, 50], 0, 10)
        surface.blit (font.render('Press ESCAPE to Exit', True, 'black'), (135, 610))
        screen.blit(surface, (0,0))
        
        for event in pygame.event.get():      
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    mainMenu()
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        
        # button procedure
        if POS_DIFFICULTY_BTN.draw(screen):
            if DIFFICULTY == 1:
                DIFFICULTY += 0.2
            elif DIFFICULTY == 0.8:
                DIFFICULTY += 0.2
        if NEG_DIFFICULTY_BTN.draw(screen):
            if DIFFICULTY == 1:
                DIFFICULTY -= 0.2

            if DIFFICULTY == 1.2:
                DIFFICULTY -= 0.2
            
        
        if POS_VOLUME_BTN.draw(screen):
            VOL += 0.2
            if VOL > 2:
                VOL = 2
         
            pygame.mixer.music.set_volume(VOL)

        if NEG_VOLUME_BTN.draw(screen):
            VOL -= 0.2
            if VOL < 0:
                VOL = 0
      
            pygame.mixer.music.set_volume(VOL)
            
        if MUS_OFF_BTN.draw(screen):
            pygame.mixer.music.set_volume(0)
        
        if MUS_ON_BTN.draw(screen):
            pygame.mixer.music.set_volume(1)
           
        
        draw_button_text('DIFFICULTY', font, textColor, 500, 200)
        draw_button_text("VOLUME", font, textColor, 500, 350)
        draw_button_text("MUSIC ON/OFF", font, textColor, 500, 500)


        pygame.display.update()

def gameMenu():
    
    global score
    global VOL
    global DIFFICULTY
    
    global level
    global level_text
        
    pygame.display.set_caption("Game")
    
    gameEnd = False
    deathEnd = False
    gamePaused = False
    optionPause = False
    
    score = 0
    
    # change music
    pygame.mixer.music.stop()
    pygame.mixer.music.unload()
    pygame.mixer.music.load(os.path.join('Assets','start_music.mp3'))
    pygame.mixer.music.play(-1)
    time.sleep(3)

    #player initialization
    player = PlayerClass.Player(width/2, height/2, charactor_image)
    
    #bring button
    start_btn = button.Button(110, 150, start_image, 0.5)
    exit_btn = button.Button(110, 450, exit_image, 0.5)
    option_btn = button.Button(110, 300, option_image, 0.5)
    
    rock_image = pygame.image.load('Assets/Rock.png').convert_alpha()
    bg2_image = pygame.image.load('Assets/ground2.png').convert_alpha()
    bg1_image = pygame.image.load('Assets/ground1.png').convert_alpha()
    lava_image = pygame.image.load('Assets/Lava.png').convert_alpha()
    
    rock = randomGenerator(screen, rock_image, True, width / 2, 120, height)
    lava = randomGenerator(screen, lava_image, True, width / 2 , 120, height)
    rock2 = randomGenerator(screen, rock_image, True, width / 4, 120, height)
    lava2 = randomGenerator(screen, lava_image, True, width / 4 , 200, height + 300)
    
    playerRect = player.getRect()
    rockRect = rock.getRect()
    lavaRect = lava.getRect()
    rock2Rect = rock2.getRect()
    lava2Rect = lava2.getRect()
    
    bg1 = backGround(screen, bg1_image, True)
    bg2 = backGround(screen, bg2_image, True)
    
    
    run = True
    
    while run: 
        
        if not gamePaused:
            clock.tick(120)
        elif gamePaused:
            clock.tick(15)
        
        #bg movement
        if score < 3500:
            level = "Crust"
            
            if not gamePaused and not deathEnd:
                score += 1
                bg1.update(3 * DIFFICULTY)
                rock.update(3 * DIFFICULTY)
                level_text = "-" + str(int(score/100)) + "km"
                draw_text(level_text, font, 'white', 0,0)
                draw_text(level, font, 'white', width * 2/5, 0)
                
                if playerRect.colliderect(rockRect):
                    # pygame.draw.rect(screen, 'red', playerRect, 4)
                    deathEnd = True

        elif score < 29000:
            level = "Mantle"
            if not gamePaused and not deathEnd:    
                score += 2
                bg2.update(6 * DIFFICULTY)
                lava.update(6 * DIFFICULTY)
                level_text = "-" + str(int(score/10)) + "km"
                draw_text(level_text, font, 'white', 0,0)
                draw_text(level, font, 'white', width * 2/5, 0)
                
                if playerRect.colliderect(lavaRect):
                    # pygame.draw.rect(screen, 'red', playerRect, 4)
                    deathEnd = True
                   
        elif score < 51000:
            level = "Outer Core"
            if not gamePaused and not deathEnd:
                score += 3
                bg2.update(4 * DIFFICULTY)
                rock2.update(4 * DIFFICULTY)
                lava2.update(4 * DIFFICULTY)
                level_text = "-" + str(int(score/10)) + "km"
                draw_text(level_text, font, 'white', 0,0)
                draw_text(level, font, 'white', width * 2/5, 0)
                
                if playerRect.colliderect(rock2Rect) or playerRect.colliderect(lava2Rect):
                    # pygame.draw.rect(screen, 'red', playerRect, 4)
                    deathEnd = True
    
        elif score < 64000:
            level = "Inner Core"
            screen.fill('white')
            screen.blit(font.render("Loading...", True, 'black'), (0,0))
            gameEnd = True
            run = False

                
        #drawing player
        if not level == "Inner Core":
            player.draw(screen)
            player.update()

        if deathEnd:
            clock.tick(0)
            drawDeath()
            
        #pause menu
        if gamePaused:
            drawPause()

            if not optionPause:
                if start_btn.draw(screen):
                    #restart button
                    gamePaused = False
                if option_btn.draw(screen):
                    optionPause = True
            
     
                if exit_btn.draw(screen):
                    pygame.quit()
                    sys.exit()
                    
            if optionPause:
                clock.tick(0)
                
                if POS_DIFFICULTY_BTN.draw(screen):
                    if DIFFICULTY == 1:
                        DIFFICULTY += 0.2
               
                        draw_text_disappear('HARD', font, textColor, 500, 100)
                    elif DIFFICULTY == 0.8:
                        DIFFICULTY += 0.2
                    
                        draw_text_disappear('NORMAL', font, textColor, 500, 100)
                if NEG_DIFFICULTY_BTN.draw(screen):
                    if DIFFICULTY == 1:
                        DIFFICULTY -= 0.2
                   
                        draw_text_disappear('EASY', font, textColor, 500, 100)
                    if DIFFICULTY == 1.2:
                        DIFFICULTY -= 0.2
                  
                        draw_text_disappear('NORMAL', font, textColor, 500, 100)
                if POS_VOLUME_BTN.draw(screen):
                    VOL += 0.2
                    if VOL > 2:
                        VOL = 2
                    
                    pygame.mixer.music.set_volume(VOL)

                if NEG_VOLUME_BTN.draw(screen):
                    VOL -= 0.2
                    if VOL < 0:
                        VOL = 0
                  
                    pygame.mixer.music.set_volume(VOL)
                    
                if MUS_OFF_BTN.draw(screen):
                    pygame.mixer.music.set_volume(0)
               
                    draw_text_disappear('MUSIC OFF', font, textColor, 500, 100)
                if MUS_ON_BTN.draw(screen):
                    pygame.mixer.music.set_volume(1)
            
                    draw_text_disappear('MUSIC ON', font, textColor, 500, 100)
                
                if exit_menu_btn.draw(screen):
                    optionPause = False

                draw_button_text('DIFFICULTY', font, textColor, 500, 200)
                draw_button_text("VOLUME", font, textColor, 500, 350)
                draw_button_text("MUSIC ON/OFF", font, textColor, 500, 500)
                draw_button_text('EXIT', font, textColor, 830, 100)
                
            
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                #checking if there is any key down.
                if event.key == pygame.K_ESCAPE and not deathEnd:
                    if gamePaused:
                        gamePaused = False
                        optionPause = False
                    else:
                        gamePaused = True
                elif event.key == pygame.K_ESCAPE and deathEnd:
                    run = False
                        
                if event.key == pygame.K_a and not gamePaused and not deathEnd:
                    player.leftPressed = True
                if event.key == pygame.K_d and not gamePaused and not deathEnd:
                    player.rightPressed = True
                if event.key == pygame.K_w and not gamePaused and not deathEnd:
                    player.upPressed = True
                if event.key == pygame.K_s and not gamePaused and not deathEnd:
                    player.downPressed = True
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    player.leftPressed = False
                if event.key == pygame.K_d:
                    player.rightPressed = False
                if event.key == pygame.K_w:
                    player.upPressed = False
                if event.key == pygame.K_s:
                    player.downPressed = False
                
            
            
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        pygame.display.flip()
        
    if gameEnd:
        endingScene()
    else:
        mainMenu()


mainMenu()

