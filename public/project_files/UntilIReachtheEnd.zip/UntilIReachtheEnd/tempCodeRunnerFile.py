            # pygame.time.delay(40000)
            # run = False